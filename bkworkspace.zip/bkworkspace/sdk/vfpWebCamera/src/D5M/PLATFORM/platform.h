//#ifndef __PLATFORM_H__
//#define __PLATFORM_H__
//
//void init_platform();
//void cleanup_platform();
//#endif // __PLATFORM_H__

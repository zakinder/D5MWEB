// LAST TESTED : 12/16/2018
#include <xil_types.h>
u32 uartcmd(u32 argA,u32 argB);
void menu_calls(int ON_OFF);
int sd_card();
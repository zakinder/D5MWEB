#ifndef __PLATFORM_H_
#define __PLATFORM_H_
int init_platform();
void cleanup_platform();
#endif

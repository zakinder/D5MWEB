// LAST TESTED : 09/01/2019
#ifndef __MENU_CALLS_H__
#define __MENU_CALLS_H__
#include <xil_types.h>
u32 uartcmd(u32 argA,u32 argB);
void menu_calls(int ON_OFF);
int sd_card();
#endif // __MENU_CALLS_H__